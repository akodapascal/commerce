<?php
return [
    'blue' => 'info',
    'red' => 'danger',
    'green' => 'success',
];