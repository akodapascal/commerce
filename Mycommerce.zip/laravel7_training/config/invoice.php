<?php

return [
  'token' => env('FACTURES_TOKEN'),
  'url' => env('FACTURES_URL'),
  'test' => env('FACTURES_TEST'),
];