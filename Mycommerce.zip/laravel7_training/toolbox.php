<?php
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}
function dumpPre($x){
    echo '<pre>';
    var_dump($x);
    echo '</pre>';
}

function printPre($x){
    echo '<pre>';
    print_r($x);
    echo '</pre>';
}

// $prenom = valid_donnees($_POST["prenom"]);
function valid_donnees($donnees){
    $donnees = trim($donnees);
    $donnees = stripslashes($donnees);
    $donnees = htmlspecialchars($donnees);
    return $donnees;
}
//nav>ul>li*5>a{menu$}
// header('Location: ' .$_SERVER['HTTP_REFERER']);

/* Générateur de Slug (Friendly Url) : convertit un titre en une URL conviviale.*/
function slugify($string, $delimiter = '-') {
	$oldLocale = setlocale(LC_ALL, '0');
	setlocale(LC_ALL, 'en_US.UTF-8');
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower($clean);
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
	$clean = trim($clean, $delimiter);
	setlocale(LC_ALL, $oldLocale);
	return $clean;
}

function tronquer_texte($texte, $nbchar)
{
    return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,
    strrpos(substr($texte,0,$nbchar)," "))." (...)" : $texte);
}