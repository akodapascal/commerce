<div class="row">
    <p>Paiement ok</p>
</div>