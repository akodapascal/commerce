## Requirement

PHP 7.4 minimum

## Install

Like any laravel project

```php
cp .env.exemple .env
composer install;
npm install
npm run dev 
php artisan key:generate
php artisan migrate // donc 
php artisan serve
```
Then run {{domain}}/ 

Example: http://127.0.0.1:8000/


## Credit

* Thanks to [Laravel Sillo](http://www.laravel.sillo.org/)
* Thanks to @FredGainza
* Thanks to @Alwil17
